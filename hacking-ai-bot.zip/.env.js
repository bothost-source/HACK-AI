# Telegram Bot Token (Get from @BotFather)
TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here

# Google Gemini API Key (Get from https://aistudio.google.com/app/apikey)
GEMINI_API_KEY=your_gemini_api_key_here

# Owner Telegram ID (Get from @userinfobot)
OWNER_ID=your_telegram_id_here

# Bot Settings
BOT_NAME=HackingAI
PREFIX=/
AUTO_READ=false

# AI Settings
AI_MODEL=gemini-1.5-flash
MAX_CONTEXT_CHUNKS=5
CHUNK_SIZE=1500
CHUNK_OVERLAP=200
